'''
tad - exercicio 1
'''

import polinomios as pl

def main():
	polinomio = str("-4x5-11x2+7x")
	print(pl.criar_polinomio(polinomio))

main()