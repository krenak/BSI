import comprimentoL2 as comp

def main():
	s = "o pão de ló"
	contagem = comp.comprimento(s)
	print(contagem)
main()